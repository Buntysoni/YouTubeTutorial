﻿using HelloWorldBLL.Interface;
using HelloWorldData.Context;
using HelloWorldData.Model;
using Microsoft.EntityFrameworkCore;

namespace HelloWorldBLL.Repository
{
    public class StudentRepository : IStudent
    {
        private readonly ApplicationDbContext _context;
        public StudentRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<(List<Students>, TransactionStatus)> GetStudentList()
        {
            List<Students> students = new List<Students>();
            TransactionStatus status = new TransactionStatus();
            try
            {
                students = await _context.Students.Select(x =>
                new Students
                {
                    id = x.id,
                    Name = x.Name,
                    Email = x.Email,
                    Phone = x.Phone,
                    PostalCode = x.PostalCode,
                    City = x.City
                }).ToListAsync();
                status.IsSuccess = true;
            }
            catch (Exception ex)
            {
                status.IsSuccess = false;
                status.message = ex.Message;
            }
            return (students, status);
        }

        public async Task<TransactionStatus> AddNewStudent(Students model)
        {
            TransactionStatus status = new TransactionStatus();
            try
            {
                var insertId = _context.Add(model);
                if (await _context.SaveChangesAsync() > 0)
                {
                    status.IsSuccess = true;
                }
                //status.IsSuccess = true;

            }
            catch (Exception ex)
            {
                status.IsSuccess = false;
                status.message = ex.Message;
            }
            return status;
        }
    }
}
