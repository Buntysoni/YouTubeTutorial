﻿using HelloWorldData.Context;
using HelloWorldData.Model;

namespace HelloWorldBLL.Interface
{
    public interface IStudent
    {
        Task<(List<Students>, TransactionStatus)> GetStudentList();
        Task<TransactionStatus> AddNewStudent(Students model);
    }
}
