﻿namespace HelloWorldBLL
{
    public class Class1
    {

    }
}