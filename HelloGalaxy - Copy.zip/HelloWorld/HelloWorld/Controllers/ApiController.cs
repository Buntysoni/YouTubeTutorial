﻿using HelloWorldBLL.Interface;
using HelloWorldData.Context;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net;
using System.Text;

namespace HelloWorld.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ApiController : ControllerBase
    {
        private readonly IStudent _student;
        public ApiController(IStudent student)
        {
            _student = student;
        }


        [HttpGet("GetStudentList")]
        public async Task<IActionResult> GetStudentList()
        {
            var result = await _student.GetStudentList();
            return Ok(new
            {
                Status = result.Item2.IsSuccess,
                RecordsTotal = result.Item1.Count,
                RecordsFiltered = 10,
                Data = result.Item1
            });
        }

        [HttpPost("AddStudent")]
        public async Task<IActionResult> AddStudent(Students model)
        {
            var result = await _student.AddNewStudent(model);
            return Ok(new
            {
                Status = result.IsSuccess
            });
        }
    }
}
