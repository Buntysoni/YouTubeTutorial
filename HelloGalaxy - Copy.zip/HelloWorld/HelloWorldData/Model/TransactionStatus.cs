﻿namespace HelloWorldData.Model
{
    public class TransactionStatus
    {
        public int id { get; set; }
        public bool IsSuccess { get; set; }
        public string? message { get; set; }
        public dynamic? data { get; set; }
        public int Code { get; set; }
    }
}
