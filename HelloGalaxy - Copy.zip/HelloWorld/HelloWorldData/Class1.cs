﻿namespace HelloWorldData
{
    public class Class1
    {

    }
}