﻿namespace HelloGalaxyData.Context
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string? Name { get; set; }
        public string? Phone { get; set; }
        public string? Email { get; set; }
        public string? Company { get; set; }
        public DateTime Date { get; set; }
        public string? Latlng { get; set; }
    }
}