﻿namespace HelloGalaxyData
{
    public class Class1
    {

    }
}