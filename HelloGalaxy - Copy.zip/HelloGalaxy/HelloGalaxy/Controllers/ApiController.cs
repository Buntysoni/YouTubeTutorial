﻿using HelloGalaxyBLL.Interface;
using HelloGalaxyData.Context;
using Microsoft.AspNetCore.Mvc;

namespace HelloGalaxy.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ApiController : ControllerBase
    {
        private readonly IEmployee _employee;
        public ApiController(IEmployee employee)
        {
            _employee = employee;
        }


        [HttpGet("GetEmployeeList")]
        public async Task<IActionResult> GetEmployeeList()
        {
            var result = await _employee.GetEmployeeList();
            return Ok(new
            {
                Status = result.Item2.IsSuccess,
                RecordsTotal = result.Item1.Count,
                RecordsFiltered = 10,
                Data = result.Item1
            });
        }

        [HttpPost("AddEmplyee")]
        public async Task<IActionResult> AddEmplyee(Employee model)
        {
            var result = await _employee.AddEmplyee(model);
            return Ok(new
            {
                Status = result.IsSuccess
            });
        }
    }
}
