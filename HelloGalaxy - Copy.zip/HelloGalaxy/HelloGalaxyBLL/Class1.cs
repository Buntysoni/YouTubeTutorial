﻿namespace HelloGalaxyBLL
{
    public class Class1
    {

    }
}