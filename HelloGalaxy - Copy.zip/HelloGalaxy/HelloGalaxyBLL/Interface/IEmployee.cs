﻿using HelloGalaxyData.Context;
using HelloGalaxyData.Model;

namespace HelloGalaxyBLL.Interface
{
    public interface IEmployee
    {
        Task<(List<Employee>, TransactionStatus)> GetEmployeeList();
        Task<TransactionStatus> AddEmplyee(Employee model);
    }
}
