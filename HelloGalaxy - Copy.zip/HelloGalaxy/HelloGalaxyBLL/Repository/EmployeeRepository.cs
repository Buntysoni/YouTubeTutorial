﻿using HelloGalaxyBLL.Interface;
using HelloGalaxyData.Context;
using HelloGalaxyData.Model;
using Microsoft.EntityFrameworkCore;

namespace HelloGalaxyBLL.Repository
{
    public class EmployeeRepository : IEmployee
    {
        private readonly ApplicationDbContext _context;
        public EmployeeRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<(List<Employee>, TransactionStatus)> GetEmployeeList()
        {
            List<Employee> employees = new List<Employee>();
            TransactionStatus status = new TransactionStatus();
            try
            {
                employees = await _context.Employee.Select(x =>
                new Employee
                {
                    EmployeeId = x.EmployeeId,
                    Name = x.Name,
                    Email = x.Email,
                    Phone = x.Phone,
                    Company = x.Company,
                    Date = x.Date,
                    Latlng = x.Latlng
                }).OrderByDescending(x => x.EmployeeId).ToListAsync();
                status.IsSuccess = true;
            }
            catch (Exception ex)
            {
                status.IsSuccess = false;
                status.message = ex.Message;
            }
            return (employees, status);
        }

        public async Task<TransactionStatus> AddEmplyee(Employee model)
        {
            TransactionStatus status = new TransactionStatus();
            try
            {
                var insertId = _context.Add(model);
                if (await _context.SaveChangesAsync() > 0)
                {
                    status.IsSuccess = true;
                }
            }
            catch (Exception ex)
            {
                status.IsSuccess = false;
                status.message = ex.Message;
            }
            return status;
        }
    }
}
